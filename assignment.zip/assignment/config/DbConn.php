<?php
error_reporting(0);

class DbConn{
    private static $obj; 
    private static $servername;
    private static $username;
    private static $password ;
    private static $dbname ;
    public static function getConnect() {
        self::$servername = "localhost";
        self::$username = "root";
        self::$password = "";
        self::$dbname= "assign_db";         
        if (!isset(self::$obj)) {             
            self::$obj =  new mysqli(self::$servername, self::$username, self::$password, self::$dbname);
        }           
        return self::$obj; 
    } 



public static function createInsertSQL($table, $data) {
    $columns = array_keys($data);
    $values = array_values($data);
    $separator = ', ';
    $v = "'" . implode ( "', '", $values ) . "'";    
    $c = implode($separator, $columns);
     $sql = "INSERT INTO {$table} ({$c}) VALUES ($v)";
    if (self::$obj->query($sql) === TRUE) {
        return  1;
    }else{
        return 0;
    }
   
}


public static function createUpdateSQL($table, $data, $where) {
  
    $set = array();
    foreach ($data as $field => $value) {
        $set[] = "$field='{$value}'";
    }
    $set = implode(', ', $set);
    
     $sql = "UPDATE {$table} SET {$set} WHERE {$where}";
    if (self::$obj->query($sql) === TRUE) {
        return  1;
    }else{
        return  0;
    }
}


public static function getAllData($sql){
    $result = self::$obj->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] =$row; 
         }
         return $data;
    }else{
        return 0;
    }
}

public static function getData($sql){
    $result = self::$obj->query($sql);
    return  $row = $result->fetch_assoc();
   
}

public static function getLastIssueID($subord, $subord_val, $increased_by = 1) {    
    $issueId = '';        
    $issueResult = self::getData("SELECT max(CAST(REPLACE(`issue_id`, '$subord','') AS UNSIGNED)) as issue_id FROM issue where issue_id LIKE '$subord_val'");
    if (isset($issueResult) && !empty($issueResult['issue_id'])) {
        $seq_no          = $issueResult['issue_id'];
        $issueId = $subord . ($seq_no + $increased_by);
    } else {
        $issueId = $subord . '1001';
    }
    return $issueId;
}


public static function getCount($sql){
    $result = self::$obj->query($sql);
    return $result->num_rows ;
}


}